-- Adds the store contact phone column referenced by the admin "Add/Edit Store"
-- form (storeFormPhone) and by SupabaseAdminSync.publishCatalog(), which now
-- sends `phone` for every store row. Run this once against your Supabase
-- project before using the updated admin console, otherwise the phone value
-- will be silently dropped by PostgREST (unknown column) or the insert may
-- fail depending on your schema cache settings.

alter table public.stores
  add column if not exists phone text;

comment on column public.stores.phone is
  'Store contact phone number, collected from the admin console (storeFormPhone).';
